package com.example.mobilelab;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Environment;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivityAudio extends AppCompatActivity {

    Button start, stop, pause;
    MediaPlayer player;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_audio);
        start = findViewById(R.id.b1);
        stop = findViewById(R.id.b2);
        pause = findViewById(R.id.b3);

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(player == null){
                    player = MediaPlayer.create(MainActivityAudio.this, R.raw.audio);
                }
                player.start();
            }
        });

        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(player != null){
                    player.release();
                    player = null;
                    Toast.makeText(MainActivityAudio.this, "Song Released", Toast.LENGTH_LONG).show();
                }
            }
        });

        pause.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(player != null){
                    player.pause();
                }
            }
        });


    }
}