package com.example.mobilelab;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.DatePickerDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;

public class MainActivityNotifi extends AppCompatActivity {

    Button b1, b2, b3, b4, b5;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_notifi);

        b1 = findViewById(R.id.b1);
        b2 = findViewById(R.id.b2);
        b3 = findViewById(R.id.b3);
        b4 = findViewById(R.id.b4);
        b5 = findViewById(R.id.b5);



        Toast.makeText(this, "Hello", Toast.LENGTH_SHORT).show();
        // TimePicker Dialog
        b1.setOnClickListener(new View.OnClickListener() {
              @Override
              public void onClick(View v) {
                  final Calendar c = Calendar.getInstance();
                  int hour = c.get(Calendar.HOUR_OF_DAY);
                  int minute = c.get(Calendar.MINUTE);
                  TimePickerDialog timePickerDialog = new TimePickerDialog(MainActivityNotifi.this,
                          new TimePickerDialog.OnTimeSetListener() {
                              @Override
                              public void onTimeSet(TimePicker view, int hourOfDay,
                                                    int minute) {
                                  Toast.makeText(MainActivityNotifi.this, hourOfDay + ":" + minute, Toast.LENGTH_LONG).show();
                              }
                          }, hour, minute, false);
                  timePickerDialog.show();

              }
          });

                // Date Picker Dialog
//           Initialize calendar instance with current date
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final Calendar calendar = Calendar.getInstance();
                int year = calendar.get(Calendar.YEAR);
                int month = calendar.get(Calendar.MONTH);
                int day = calendar.get(Calendar.DAY_OF_MONTH);

                // Create DatePickerDialog and show it
                DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivityNotifi.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                        // Do something with the selected date
                        String selectedDate = day + "/" + (month + 1) + "/" + year;
                        Toast.makeText(MainActivityNotifi.this, "Selected date: " + selectedDate, Toast.LENGTH_SHORT).show();
                    }
                }, year, month, day);

                datePickerDialog.show();
//
            }
        });




        //Status Notification
        String channelId = "my_channel_id";
        String channelName = "My Channel";
        int importance = NotificationManager.IMPORTANCE_HIGH;
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(channelId, channelName, importance);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }


        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                NotificationCompat.Builder builder = new NotificationCompat.Builder(MainActivityNotifi.this, channelId)
                        .setSmallIcon(R.drawable.ic_launcher_background)
                        .setContentTitle("My Notification")
                        .setContentText("Someone has entered the room")
                        .setPriority(NotificationCompat.PRIORITY_HIGH);

//                NotificationManagerCompat managerCompat = NotificationManagerCompat.from(MainActivityHome.this);
//                managerCompat.notify(1, builder.build());

                NotificationManager mNotificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
                mNotificationManager.notify(001, builder.build());

            }
        });


        // Progress Dialog
        ProgressDialog progress=new ProgressDialog(this);

        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Progress bar
                progress.setMessage("Proceeding to bio-lock");
                progress.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
                // progress.setIndeterminate(true);
                progress.setProgress(0);
                progress.show();
                final int totalProgressTime = 100;
                final Thread t = new Thread() {
                    @Override
                    public void run() {
                        int jumpTime = 0;
                        while(jumpTime < totalProgressTime) {
                            try {
                                Thread.sleep(200);
                                jumpTime += 5;
                                progress.setProgress(jumpTime);
                            } catch (InterruptedException e) {
                                // TODO Auto-generated catch block
                                e.printStackTrace();
                            }
                        }
                        progress.dismiss();
                        if (jumpTime == totalProgressTime) {
                            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                            startActivity(cameraIntent);
                        }
                    }
                };
                t.start();
//                Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
//                startActivity(takePictureIntent);
            }
        });


        b5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Alert Notification
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivityNotifi.this);
                builder.setTitle("Alert Dialog");
                builder.setMessage("Are you sure you want to visit this page?");
                builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // User clicked Yes button
                    }
                });
                builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // User clicked No button
                        dialog.cancel();
                    }
                });
                AlertDialog alertDialog = builder.create();
                alertDialog.show();
            }
        });

    }
}